// BounceWars relay server: rooms of max 2 players, messages are broadcast to the room.
const { WebSocketServer } = require('ws');
const wss = new WebSocketServer({ port: process.env.PORT || 8080, maxPayload: 4096 });
const rooms = new Map();
let next = 1;
const send = (c, o) => c.readyState === 1 && c.send(JSON.stringify(o));
const count = (set) => set.forEach((c) => send(c, { n: set.size }));
wss.on('connection', (ws) => {
  ws.id = 'c' + next++;
  ws.room = null;
  send(ws, { id: ws.id });
  ws.on('message', (raw) => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (typeof m.j === 'string' && /^[A-Za-z0-9]{4}$/.test(m.j) && !ws.room) {
      const set = rooms.get(m.j) || new Set();
      if (set.size >= 2) return ws.close();
      set.add(ws); rooms.set(m.j, set); ws.room = m.j; count(set);
    } else if (m.d !== undefined && ws.room) {
      rooms.get(ws.room).forEach((c) => send(c, { d: m.d, f: ws.id }));
    }
  });
  ws.on('close', () => {
    const set = rooms.get(ws.room);
    if (!set) return;
    set.delete(ws);
    if (!set.size) rooms.delete(ws.room); else count(set);
  });
});
console.log('BounceWars server on port', process.env.PORT || 8080);
