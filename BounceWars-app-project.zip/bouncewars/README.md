# BounceWars

Native Android/iOS app (Capacitor wrapper around the game in `www/index.html`).

## Build the app
Requirements: Node.js 18+, Android Studio (Android) and/or Xcode on a Mac (iOS).

```
npm install
npx cap add android      # and/or: npx cap add ios
npx cap sync
npx cap open android     # builds/runs in Android Studio (Build > Build APK)
npx cap open ios         # builds/runs in Xcode
```

After every change in `www/` run `npx cap sync`.
App icon and splash: `npm i -D @capacitor/assets`, put `assets/icon.png` (1024x1024), run `npx capacitor-assets generate`.

## Online mode
Online play needs a small relay server (`server/`):

```
cd server && npm install && node server.js
```

Deploy it anywhere that supports WebSockets (Render, Fly.io, Railway, a VPS) behind TLS,
then enter its address (e.g. `wss://your-server.com`) in the app: Settings > Online server.
Local and bot modes work without a server.

## Settings
Volume, vibration (on/off) and language (English, Polski, Deutsch, Español) are stored on the device.
To add a language, add an entry to the `D` object in `www/index.html` and an `<option>` in the language select.
